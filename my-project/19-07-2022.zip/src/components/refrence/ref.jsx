function Ref() {
    return ( <>Ref</> );
}

export default Ref;