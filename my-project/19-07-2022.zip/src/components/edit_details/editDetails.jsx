function EditDetails() {
    return ( <>Edit details</> );
}

export default EditDetails;